"""FastMCP CLI as a runnable package"""

from .cli import app

app()
