from .component_manager import set_up_component_manager

__all__ = ["set_up_component_manager"]
