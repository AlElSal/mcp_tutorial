"""Vendored third-party code for FastMCP."""
